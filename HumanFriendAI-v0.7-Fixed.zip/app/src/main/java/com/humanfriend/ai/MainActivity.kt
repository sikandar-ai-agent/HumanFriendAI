package com.humanfriend.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val serverUrl = "http://10.185.58.206:5000/chat"
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                HumanFriendScreen(
                    onSend = { message, update ->
                        sendToServer(message, update)
                    }
                )
            }
        }
    }

    private fun sendToServer(message: String, update: (String) -> Unit) {
        update("میسج بھیجا جا رہا ہے...")

        val payload = JSONObject().put("message", message)
        val body = payload.toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(serverUrl)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    update("رابطہ کرنے میں خرابی: ${e.localizedMessage ?: "نامعلوم خرابی"}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val text = it.body?.string().orEmpty()
                    val reply = if (it.isSuccessful) {
                        try {
                            JSONObject(text).optString("response", "کوئی جواب نہیں ملا")
                        } catch (_: Exception) {
                            "سرور کا جواب پڑھا نہیں جا سکا۔"
                        }
                    } else {
                        "سرور کی طرف سے خرابی کا کوڈ: ${it.code}"
                    }
                    runOnUiThread { update(reply) }
                }
            }
        })
    }
}

@Composable
private fun HumanFriendScreen(onSend: (String, (String) -> Unit) -> Unit) {
    var message by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("السلام علیکم! میں HumanFriendAI ہوں۔ آپ کیا پوچھنا چاہتے ہیں؟") }
    var busy by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Human Friend AI", style = MaterialTheme.typography.headlineMedium)
            Text("آپ کا AI دوست", style = MaterialTheme.typography.titleMedium)
            Surface(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                tonalElevation = 2.dp
            ) {
                Text(
                    text = reply,
                    modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("اپنا پیغام لکھیں") },
                enabled = !busy,
                minLines = 2
            )
            Button(
                onClick = {
                    val text = message.trim()
                    if (text.isNotEmpty() && !busy) {
                        busy = true
                        onSend(text) { result ->
                            reply = result
                            busy = false
                        }
                        message = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = message.isNotBlank() && !busy
            ) {
                Text(if (busy) "جواب کا انتظار..." else "پیغام بھیجیں")
            }
        }
    }
}
