# Human Friend AI — Online APK Build

This is the simplified project.

## Recommended online build

Use an online Android CI service such as GitHub Actions.

### GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this ZIP.
3. Create:
   `.github/workflows/android.yml`
4. Put the workflow from `android-build-workflow.yml` into that folder.
5. Open GitHub -> Actions.
6. Run **Build Human Friend AI APK**.
7. Download the generated `HumanFriendAI-debug-apk` artifact.
8. On the Samsung phone, open the APK and install it.

## If Android blocks installation

Android may ask permission to install apps from the browser/file manager you used. Allow that permission only for the app you are using to install the APK.

## Important

This build is intentionally a clean client project. The advanced backend features (Hugging Face, autonomous web browsing, long-term cloud memory, file processing) should be connected through a secure backend after the basic APK is working.

Do not put private Hugging Face API keys directly into the APK.
