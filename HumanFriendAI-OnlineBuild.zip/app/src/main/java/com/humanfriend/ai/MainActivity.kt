package com.humanfriend.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

enum class Language(
    val label: String,
    val rtl: Boolean
) {
    AUTO("Auto Detect", false),
    ENGLISH("English", false),
    URDU("اردو", true),
    HINDI("हिन्दी", false),
    ARABIC("العربية", true)
}

data class Message(
    val user: Boolean,
    val text: String,
    val fileName: String? = null
)

class HumanFriendViewModel : ViewModel() {
    var language by mutableStateOf(Language.AUTO)
        private set

    var browsing by mutableStateOf(true)
        private set

    var learning by mutableStateOf(true)
        private set

    var messages by mutableStateOf(
        listOf(
            Message(
                false,
                "Hello! I'm Human Friend AI. I support English, Urdu, Hindi and Arabic. " +
                    "Memory, learning, web browsing and file handling are part of the design."
            )
        )
    )
        private set

    fun setLanguage(value: Language) {
        language = value
    }

    fun setBrowsing(value: Boolean) {
        browsing = value
    }

    fun setLearning(value: Boolean) {
        learning = value
    }

    fun send(text: String, fileName: String?) {
        if (text.isBlank() && fileName == null) return

        messages = messages + Message(
            true,
            text.ifBlank { "File attached" },
            fileName
        )

        val reply = when (language) {
            Language.URDU ->
                "سمجھ گیا۔ میں اس گفتگو میں آپ کی منتخب زبان، یادداشت اور فائل کو مدنظر رکھ سکتا ہوں۔"
            Language.HINDI ->
                "समझ गया। मैं इस बातचीत में आपकी चुनी हुई भाषा, याददाश्त और फ़ाइल को ध्यान में रख सकता हूँ।"
            Language.ARABIC ->
                "فهمت. يمكنني استخدام اللغة والذاكرة والملف الذي اخترته ضمن هذه المحادثة."
            else ->
                "Got it. I can use your selected language, memory, learning, web research and attached files when the backend is connected."
        }

        messages = messages + Message(false, reply, fileName)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                val vm: HumanFriendViewModel = viewModel()
                HumanFriendApp(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HumanFriendApp(vm: HumanFriendViewModel) {
    var languageMenu by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedFile = uri.lastPathSegment ?: "Selected file"
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides
            if (vm.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Human Friend AI") },
                    actions = {
                        TextButton(onClick = { languageMenu = true }) {
                            Text("🌐 ${vm.language.label}")
                        }

                        DropdownMenu(
                            expanded = languageMenu,
                            onDismissRequest = { languageMenu = false }
                        ) {
                            Language.entries.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item.label) },
                                    onClick = {
                                        vm.setLanguage(item)
                                        languageMenu = false
                                    }
                                )
                            }
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Web")
                    Switch(
                        checked = vm.browsing,
                        onCheckedChange = vm::setBrowsing
                    )
                    Spacer(Modifier.width(12.dp))
                    Text("Learning")
                    Switch(
                        checked = vm.learning,
                        onCheckedChange = vm::setLearning
                    )
                }

                selectedFile?.let {
                    Spacer(Modifier.height(6.dp))
                    AssistChip(
                        onClick = { selectedFile = null },
                        label = { Text("📎 $it") }
                    )
                }

                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(vm.messages) { message ->
                        Surface(
                            tonalElevation = 2.dp,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(message.text)
                                message.fileName?.let {
                                    Spacer(Modifier.height(4.dp))
                                    Text("📎 $it")
                                }
                            }
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            picker.launch(
                                arrayOf(
                                    "application/pdf",
                                    "image/*",
                                    "video/*",
                                    "text/plain",
                                    "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                )
                            )
                        }
                    ) {
                        Text("📎")
                    }

                    Spacer(Modifier.width(6.dp))

                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Talk to Human Friend AI...") },
                        maxLines = 4
                    )

                    Spacer(Modifier.width(6.dp))

                    Button(
                        onClick = {
                            vm.send(text, selectedFile)
                            text = ""
                            selectedFile = null
                        }
                    ) {
                        Text("Send")
                    }
                }
            }
        }
    }
}
