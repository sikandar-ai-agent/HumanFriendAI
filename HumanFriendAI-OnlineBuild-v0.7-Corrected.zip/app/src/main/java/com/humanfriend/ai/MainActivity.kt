package com.humanfriend.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

enum class AppLanguage(val label: String, val rtl: Boolean) {
    AUTO("Auto Detect", false),
    ENGLISH("English", false),
    URDU("اردو", true),
    HINDI("हिन्दी", false),
    ARABIC("العربية", true)
}

data class Message(
    val text: String,
    val user: Boolean = false,
    val fileName: String? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HumanFriendAI() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HumanFriendAI() {
    var language by remember { mutableStateOf(AppLanguage.AUTO) }
    var languageMenu by remember { mutableStateOf(false) }
    var browsing by remember { mutableStateOf(true) }
    var learning by remember { mutableStateOf(true) }
    var input by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf<String?>(null) }

    var messages by remember {
        mutableStateOf(
            listOf(
                Message(
                    "Hello! I'm Human Friend AI. I support English, Urdu, Hindi and Arabic. " +
                    "Memory, learning, web research and file support are built into this project."
                )
            )
        )
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedFile = uri.lastPathSegment ?: "selected file"
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides
            if (language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Human Friend AI") },
                    actions = {
                        TextButton(onClick = { languageMenu = true }) {
                            Text("🌐 ${language.label}")
                        }
                        DropdownMenu(
                            expanded = languageMenu,
                            onDismissRequest = { languageMenu = false }
                        ) {
                            AppLanguage.entries.forEach {
                                DropdownMenuItem(
                                    text = { Text(it.label) },
                                    onClick = {
                                        language = it
                                        languageMenu = false
                                    }
                                )
                            }
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Web")
                    Switch(checked = browsing, onCheckedChange = { browsing = it })
                    Spacer(Modifier.width(12.dp))
                    Text("Learning")
                    Switch(checked = learning, onCheckedChange = { learning = it })
                }

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            tonalElevation = 2.dp,
                            shape = MaterialTheme.shapes.medium
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(it.text)
                                it.fileName?.let { name ->
                                    Spacer(Modifier.height(4.dp))
                                    Text("📎 $name")
                                }
                            }
                        }
                    }
                }

                selectedFile?.let {
                    AssistChip(
                        onClick = { selectedFile = null },
                        label = { Text("📎 $it") }
                    )
                    Spacer(Modifier.height(6.dp))
                }

                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            picker.launch(
                                arrayOf(
                                    "application/pdf",
                                    "image/*",
                                    "video/*",
                                    "text/plain",
                                    "application/msword",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "application/vnd.oasis.opendocument.text"
                                )
                            )
                        }
                    ) {
                        Text("📎")
                    }

                    Spacer(Modifier.width(6.dp))

                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Talk to me...") },
                        maxLines = 4
                    )

                    Spacer(Modifier.width(6.dp))

                    Button(
                        onClick = {
                            if (input.isBlank() && selectedFile == null) return@Button

                            messages = messages + Message(
                                text = input.ifBlank { "File attached" },
                                user = true,
                                fileName = selectedFile
                            )

                            val features = buildString {
                                append("I received your message.")
                                if (selectedFile != null) {
                                    append(" I also received ${selectedFile}.")
                                }
                                append(
                                    " This build is ready for connection to the Human Friend backend, " +
                                    "where memory, self-learning, web research, Hugging Face AI, " +
                                    "and file processing will run."
                                )
                            }

                            messages = messages + Message(features)
                            input = ""
                            selectedFile = null
                        }
                    ) {
                        Text("Send")
                    }
                }
            }
        }
    }
}
