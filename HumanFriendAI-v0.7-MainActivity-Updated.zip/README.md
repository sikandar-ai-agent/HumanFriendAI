# Human Friend AI — Online Build Project v0.7

This is the corrected Android client project for GitHub Actions.

Build configuration:
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Kotlin Compose compiler plugin 2.0.21
- Java/JVM target 17
- Gradle 8.10 (provided by the GitHub Actions workflow)
- compileSdk 35 / targetSdk 35 / minSdk 26
- Jetpack Compose

Important:
- This APK is a client prototype. Hugging Face, web research, long-term cloud memory,
  controlled learning, and server-side file processing should be connected through a
  secure backend.
- Never put a private Hugging Face API token directly in the APK or a public repository.
