package com.humanfriend.ai

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var inputMessage: EditText
    private lateinit var sendButton: Button
    private lateinit var responseText: TextView

    private val serverUrl = "http://10.185.58.206:5000/chat"
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputMessage = findViewById(R.id.inputMessage)
        sendButton = findViewById(R.id.sendButton)
        responseText = findViewById(R.id.responseText)

        sendButton.setOnClickListener {
            val message = inputMessage.text.toString().trim()
            if (message.isNotEmpty()) {
                sendToServer(message)
            }
        }
    }

    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun sendToServer(message: String) {
        responseText.text = "میسج بھیجا جا رہا ہے..."

        val json = JSONObject()
        json.put("message", message)

        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(serverUrl)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                mainHandler.post {
                    responseText.text = "رابطہ کرنے میں خرابی: ${e.message}"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    val jsonResponse = JSONObject(responseBody ?: "")
                    val aiReply = jsonResponse.optString("response", "کوئی جواب نہیں ملا")

                    mainHandler.post {
                        responseText.text = aiReply
                    }
                } else {
                    mainHandler.post {
                        responseText.text = "سرور کی طرف سے خرابی کا کوڈ: ${response.code}"
                    }
                }
            }
        })
    }
}
